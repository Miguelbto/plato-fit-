import React from 'react';
import { Heart, Utensils } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-800 text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <div className="bg-orange-500 p-2 rounded-lg">
                <Utensils className="h-6 w-6 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold">Platô Fit</h3>
                <p className="text-sm text-orange-400">Refeições Saudáveis</p>
              </div>
            </div>
            <p className="text-gray-300 leading-relaxed">
              Alimentação saudável, saborosa e prática para quem busca qualidade de vida 
              e resultados no fitness.
            </p>
          </div>

          <div>
            <h4 className="font-bold mb-4">Nossos Valores</h4>
            <ul className="space-y-2 text-gray-300">
              <li>• Qualidade em primeiro lugar</li>
              <li>• Ingredientes frescos e naturais</li>
              <li>• Nutrição balanceada</li>
              <li>• Praticidade no dia a dia</li>
              <li>• Atendimento personalizado</li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-4">Frases Inspiradoras</h4>
            <div className="space-y-3 text-gray-300">
              <p className="italic">"Sua saúde começa pela sua alimentação"</p>
              <p className="italic">"Comida saudável com sabor de verdade"</p>
              <p className="italic">"Seu objetivo, nossa missão"</p>
              <p className="italic">"Refeições prontas para seu dia render mais"</p>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-8 text-center">
          <p className="text-gray-400 flex items-center justify-center space-x-2">
            <span>© 2025 Platô Fit. Feito com</span>
            <Heart className="h-4 w-4 text-orange-500" />
            <span>para sua saúde.</span>
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;