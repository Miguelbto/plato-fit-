import React from 'react';
import { Users, Award, Clock, Shield } from 'lucide-react';

const About = () => {
  const features = [
    {
      icon: <Users className="h-8 w-8 text-orange-500" />,
      title: "Para Todos os Objetivos",
      description: "Cutting, manutenção ou bulking - temos a refeição ideal para seu objetivo fitness."
    },
    {
      icon: <Award className="h-8 w-8 text-orange-500" />,
      title: "Qualidade Premium",
      description: "Ingredientes frescos e selecionados, preparados com técnicas que preservam os nutrientes."
    },
    {
      icon: <Clock className="h-8 w-8 text-orange-500" />,
      title: "Praticidade Total",
      description: "Refeições prontas que cabem na sua rotina corrida, sem abrir mão da qualidade."
    },
    {
      icon: <Shield className="h-8 w-8 text-orange-500" />,
      title: "Segurança Alimentar",
      description: "Processos rigorosos de higiene e conservação para garantir sua segurança."
    }
  ];

  return (
    <section id="sobre" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-4xl font-bold text-gray-800 mb-6">
              Sobre a Platô Fit
            </h2>
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              Somos uma empresa brasileira especializada em refeições saudáveis e práticas, 
              com foco em alimentação fitness e equilibrada. Nossa missão é fornecer alimentação 
              saudável, saborosa e acessível para pessoas que valorizam saúde, bem-estar e 
              desempenho no dia a dia.
            </p>
            
            <div className="space-y-6">
              <div className="flex items-start space-x-4">
                <div className="bg-orange-100 p-2 rounded-lg flex-shrink-0">
                  <Award className="h-6 w-6 text-orange-500" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-800 mb-1">Nutrição Balanceada</h3>
                  <p className="text-gray-600">Cada refeição é cuidadosamente balanceada para atender suas necessidades nutricionais específicas.</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="bg-orange-100 p-2 rounded-lg flex-shrink-0">
                  <Users className="h-6 w-6 text-orange-500" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-800 mb-1">Para Atletas e Entusiastas</h3>
                  <p className="text-gray-600">Atendemos desde atletas profissionais até pessoas que buscam uma vida mais saudável.</p>
                </div>
              </div>
            </div>

            <div className="mt-8">
              <blockquote className="text-xl italic text-gray-700 border-l-4 border-orange-500 pl-6">
                "Feitas com carinho, entregues com saúde"
              </blockquote>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-6">
            {features.map((feature, index) => (
              <div key={index} className="bg-gray-50 p-6 rounded-2xl hover:bg-orange-50 transition-colors duration-300">
                <div className="mb-4">
                  {feature.icon}
                </div>
                <h3 className="font-bold text-gray-800 mb-2">{feature.title}</h3>
                <p className="text-sm text-gray-600 leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;