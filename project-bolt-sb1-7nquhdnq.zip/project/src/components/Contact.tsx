import React from 'react';
import { Phone, MapPin, Clock, MessageCircle } from 'lucide-react';

const Contact = () => {
  return (
    <section id="contato" className="py-20 bg-gradient-to-br from-orange-500 to-orange-600">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-4">
            Entre em Contato
          </h2>
          <p className="text-xl text-orange-100 max-w-3xl mx-auto">
            Pronto para começar sua jornada fitness com refeições saudáveis? 
            Entre em contato conosco e faça seu pedido!
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 text-center">
            <div className="bg-white/20 p-3 rounded-full w-fit mx-auto mb-4">
              <Phone className="h-6 w-6 text-white" />
            </div>
            <h3 className="font-bold text-white mb-2">Telefone</h3>
            <p className="text-orange-100">(11) 94061-9777</p>
          </div>

          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 text-center">
            <div className="bg-white/20 p-3 rounded-full w-fit mx-auto mb-4">
              <MessageCircle className="h-6 w-6 text-white" />
            </div>
            <h3 className="font-bold text-white mb-2">WhatsApp</h3>
            <p className="text-orange-100">Pedidos e dúvidas</p>
          </div>

          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 text-center">
            <div className="bg-white/20 p-3 rounded-full w-fit mx-auto mb-4">
              <Clock className="h-6 w-6 text-white" />
            </div>
            <h3 className="font-bold text-white mb-2">Horário</h3>
            <p className="text-orange-100">Seg-Sex: 8h às 18h</p>
          </div>

          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 text-center">
            <div className="bg-white/20 p-3 rounded-full w-fit mx-auto mb-4">
              <MapPin className="h-6 w-6 text-white" />
            </div>
            <h3 className="font-bold text-white mb-2">Entrega</h3>
            <p className="text-orange-100">São Paulo e região</p>
          </div>
        </div>

        <div className="text-center">
          <a 
            href="tel:+5511940619777" 
            className="bg-white text-orange-500 px-8 py-4 rounded-full text-lg font-semibold hover:bg-orange-50 transition-colors inline-flex items-center space-x-3 shadow-lg"
          >
            <Phone className="h-5 w-5" />
            <span>Ligar Agora: (11) 94061-9777</span>
          </a>
        </div>

        <div className="mt-16 text-center">
          <div className="grid md:grid-cols-3 gap-8 text-white">
            <div>
              <h4 className="font-bold mb-2">Refeições Prontas</h4>
              <p className="text-orange-100 text-sm">Entregues fresquinhas na sua casa ou trabalho</p>
            </div>
            <div>
              <h4 className="font-bold mb-2">Cardápio Variado</h4>
              <p className="text-orange-100 text-sm">Opções para todos os gostos e objetivos</p>
            </div>
            <div>
              <h4 className="font-bold mb-2">Qualidade Garantida</h4>
              <p className="text-orange-100 text-sm">Ingredientes frescos e preparo cuidadoso</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;