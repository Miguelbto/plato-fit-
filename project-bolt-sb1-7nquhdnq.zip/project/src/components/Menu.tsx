import React from 'react';
import { Leaf, Flame, TrendingUp, Star, Crown } from 'lucide-react';

const Menu = () => {
  const specialDishes = [
    {
      id: 1,
      name: "Parmegiana de Berinjela",
      description: "Versão vegetariana rica em sabor e nutrientes, com queijo derretido e molho especial",
      image: "/ChatGPT Image 13 de jun. de 2025, 18_52_53.png",
      category: "Vegetariano",
      goal: "cutting",
      icon: <Leaf className="h-4 w-4" />
    },
    {
      id: 2,
      name: "Strogonoff de Frango Saudável",
      description: "Feito com creme leve e porções balanceadas, acompanha arroz integral",
      image: "/ChatGPT Image 13 de jun. de 2025, 18_55_37.png",
      category: "Proteína",
      goal: "maintenance",
      icon: <Flame className="h-4 w-4" />
    },
    {
      id: 3,
      name: "Macarrão à Bolonhesa Fitness",
      description: "Massa integral com molho bolonhesa de carne magra e vegetais coloridos",
      image: "/ChatGPT Image 13 de jun. de 2025, 18_52_44.png",
      category: "Proteína",
      goal: "bulking",
      icon: <TrendingUp className="h-4 w-4" />
    }
  ];

  const classicDishes = [
    {
      id: 4,
      name: "Frango Grelhado Funcional",
      description: "Frango grelhado com arroz integral, feijão e mix de vegetais frescos",
      image: "/ChatGPT Image 13 de jun. de 2025, 18_53_19.png",
      category: "Proteína",
      goal: "bulking",
      icon: <TrendingUp className="h-4 w-4" />
    },
    {
      id: 5,
      name: "Carne Grelhada Premium",
      description: "Carne magra grelhada com purê de batata doce e vegetais coloridos",
      image: "/ChatGPT Image 13 de jun. de 2025, 18_53_05.png",
      category: "Proteína",
      goal: "bulking",
      icon: <TrendingUp className="h-4 w-4" />
    },
    {
      id: 6,
      name: "Peixe Grelhado Fresh",
      description: "Peixe grelhado com salada fresca e carboidrato leve",
      image: "/ChatGPT Image 13 de jun. de 2025, 19_00_31.png",
      category: "Proteína",
      goal: "cutting",
      icon: <Leaf className="h-4 w-4" />
    }
  ];

  const getGoalBadge = (goal: string) => {
    switch (goal) {
      case 'cutting':
        return <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium">Cutting</span>;
      case 'maintenance':
        return <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs font-medium">Manutenção</span>;
      case 'bulking':
        return <span className="bg-purple-100 text-purple-800 px-2 py-1 rounded-full text-xs font-medium">Bulking</span>;
      default:
        return null;
    }
  };

  const DishCard = ({ dish, isSpecial = false }: { dish: any, isSpecial?: boolean }) => (
    <div className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300 group relative">
      {isSpecial && (
        <div className="absolute top-2 left-2 z-10 bg-gradient-to-r from-orange-500 to-orange-600 text-white px-3 py-1 rounded-full text-xs font-bold flex items-center space-x-1">
          <Crown className="h-3 w-3" />
          <span>ESPECIAL</span>
        </div>
      )}
      
      <div className="relative overflow-hidden">
        <img 
          src={dish.image} 
          alt={dish.name}
          className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute top-4 right-4">
          {getGoalBadge(dish.goal)}
        </div>
        <div className="absolute bottom-4 right-4 bg-white/90 backdrop-blur-sm p-2 rounded-full">
          {dish.icon}
        </div>
      </div>
      
      <div className="p-6">
        <h3 className="text-xl font-bold text-gray-800 mb-2">{dish.name}</h3>
        <p className="text-gray-600 mb-4 leading-relaxed">{dish.description}</p>
        
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium text-orange-500 bg-orange-50 px-3 py-1 rounded-full">
            {dish.category}
          </span>
          <button className="bg-orange-500 text-white px-4 py-2 rounded-full text-sm font-medium hover:bg-orange-600 transition-colors">
            Pedir Agora
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <section id="cardapio" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">
            Nosso Cardápio
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Refeições balanceadas para todos os objetivos: cutting, manutenção e bulking. 
            Cada prato é cuidadosamente preparado para maximizar seus resultados.
          </p>
        </div>

        {/* Marmitas Especiais */}
        <div className="mb-16">
          <div className="flex items-center justify-center mb-8">
            <div className="flex items-center space-x-3">
              <Star className="h-6 w-6 text-orange-500" />
              <h3 className="text-3xl font-bold text-gray-800">Marmitas Especiais</h3>
              <Star className="h-6 w-6 text-orange-500" />
            </div>
          </div>
          <p className="text-center text-gray-600 mb-8 max-w-2xl mx-auto">
            Nossas criações exclusivas com sabores únicos e preparos especiais
          </p>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {specialDishes.map((dish) => (
              <DishCard key={dish.id} dish={dish} isSpecial={true} />
            ))}
          </div>
        </div>

        {/* Marmitas Clássicas */}
        <div className="mb-12">
          <div className="flex items-center justify-center mb-8">
            <div className="flex items-center space-x-3">
              <Flame className="h-6 w-6 text-orange-500" />
              <h3 className="text-3xl font-bold text-gray-800">Marmitas Clássicas</h3>
              <Flame className="h-6 w-6 text-orange-500" />
            </div>
          </div>
          <p className="text-center text-gray-600 mb-8 max-w-2xl mx-auto">
            Nossos pratos tradicionais, sempre frescos e nutritivos
          </p>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {classicDishes.map((dish) => (
              <DishCard key={dish.id} dish={dish} />
            ))}
          </div>
        </div>

        <div className="text-center mt-12">
          <a 
            href="tel:+5511940619777" 
            className="bg-orange-500 text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-orange-600 transition-colors inline-flex items-center space-x-2"
          >
            <span>Fazer Pedido Personalizado</span>
          </a>
        </div>
      </div>
    </section>
  );
};

export default Menu;