import React from 'react';
import { Heart, Zap, Target } from 'lucide-react';

const Hero = () => {
  return (
    <section id="inicio" className="bg-gradient-to-br from-orange-50 to-white py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-5xl lg:text-6xl font-bold text-gray-800 leading-tight mb-6">
              Sua saúde começa pela sua 
              <span className="text-orange-500"> alimentação</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 leading-relaxed">
              Refeições saudáveis, saborosas e balanceadas, prontas para seu dia render mais. 
              Feitas com carinho, entregues com saúde.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 mb-12">
              <a 
                href="#cardapio" 
                className="bg-orange-500 text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-orange-600 transition-colors text-center"
              >
                Ver Cardápio
              </a>
              <a 
                href="tel:+5511940619777" 
                className="border-2 border-orange-500 text-orange-500 px-8 py-4 rounded-full text-lg font-semibold hover:bg-orange-500 hover:text-white transition-colors text-center"
              >
                Fazer Pedido
              </a>
            </div>

            <div className="grid grid-cols-3 gap-6">
              <div className="text-center">
                <div className="bg-orange-100 p-3 rounded-full w-fit mx-auto mb-3">
                  <Heart className="h-6 w-6 text-orange-500" />
                </div>
                <p className="text-sm font-medium text-gray-700">Comida saudável com sabor de verdade</p>
              </div>
              <div className="text-center">
                <div className="bg-orange-100 p-3 rounded-full w-fit mx-auto mb-3">
                  <Target className="h-6 w-6 text-orange-500" />
                </div>
                <p className="text-sm font-medium text-gray-700">Seu objetivo, nossa missão</p>
              </div>
              <div className="text-center">
                <div className="bg-orange-100 p-3 rounded-full w-fit mx-auto mb-3">
                  <Zap className="h-6 w-6 text-orange-500" />
                </div>
                <p className="text-sm font-medium text-gray-700">Energia para seu dia</p>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="bg-white rounded-3xl shadow-2xl p-8 transform rotate-3 hover:rotate-0 transition-transform duration-300">
              <img 
                src="/ChatGPT Image 13 de jun. de 2025, 18_53_19.png" 
                alt="Refeição saudável Platô Fit" 
                className="w-full h-80 object-cover rounded-2xl"
              />
              <div className="mt-6 text-center">
                <h3 className="text-xl font-bold text-gray-800 mb-2">Frango Grelhado Funcional</h3>
                <p className="text-gray-600">Arroz integral, feijão e vegetais frescos</p>
              </div>
            </div>
            
            {/* Floating elements */}
            <div className="absolute -top-4 -left-4 bg-orange-500 text-white px-4 py-2 rounded-full text-sm font-semibold shadow-lg">
              100% Natural
            </div>
            <div className="absolute -bottom-4 -right-4 bg-white text-orange-500 px-4 py-2 rounded-full text-sm font-semibold shadow-lg border-2 border-orange-500">
              Entrega Rápida
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;